# Channel Logos

Place your channel logo images in this directory.

## Required Images

| Filename | Used For |
|----------|----------|
| `sky_sports.png` | Sky Sports channels |
| `tnt_sports.jfif` | TNT Sports channels |
| `star_sports_1.png` | Star Sports 1 |
| `star_sports_2.png` | Star Sports 2 |
| `star_sports_3.jpg` | Star Sports 3 |
| `sony_sports_1.png` | Sony Sports Ten 1 |
| `sony_sports_2.png` | Sony Sports Ten 2 |
| `sony_sports_3.png` | Sony Sports Ten 3 |
| `sony_sports_5.png` | Sony Sports Ten 5 |
| `ptv.jfif` | PTV Sports |
| `a_sports.jfif` | A Sports |
| `astro_cricket.png` | Astro Cricket |
| `willow_sports.jfif` | Willow Sports |
| `geo_super.png` | Geo Super |
| `super_sport.jpg` | Super Sport channels |
| `tsn.jpg` | TSN channels |
| `viaplay.jfif` | Viaplay channels |
| `eurosport.jpg` | Eurosport channels |

## Recommended Specifications
- Format: PNG or JPEG
- Size: 300x300px minimum
- Aspect Ratio: 1:1 or 16:9
- Max file size: 100KB per image
