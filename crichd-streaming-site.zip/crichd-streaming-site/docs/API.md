# API Documentation

## URL Parameters

### index.php
No parameters required.

### play.php
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `c` | string | Yes | Channel identifier (alphanumeric + underscore) |

**Example:**
```
/play.php?c=skysme
```

### embed.php
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `id` | string | Yes | Stream identifier |

**Example:**
```
/embed.php?id=skysme
```

### plays.php
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `max` | string | Yes | Direct stream URL (HLS .m3u8) |

**Example:**
```
/plays.php?max=https://example.com/stream.m3u8
```

### kplay.php
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `max` | string | Yes | Direct stream URL |

**Example:**
```
/kplay.php?max=https://example.com/stream.m3u8
```

### animal_plannet.php
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `max` | string | No | Stream URL (defaults to local .m3u8) |

### playshemaroo.php
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `max` | string | Yes | Base stream URL (HMAC token appended automatically) |

## Channel IDs

### Sky Sports
| ID | Channel |
|----|---------|
| `skysme` | Sky Sports Main Events |
| `skyscric` | Sky Sports Cricket |
| `skysfott` | Sky Sports Football |
| `skysare` | Sky Sports Arena |
| `skysact` | Sky Sports Action |
| `skysgol` | Sky Sports Golf |
| `skysprem` | Sky Sports Premier League |
| `skysfor1` | Sky Sports F1 |
| `skysmixx` | Sky Sports MIX |
| `skysnews` | Sky Sports News |

### Star Sports
| ID | Channel |
|----|---------|
| `star1in` | Star Sports 1 |
| `star2in` | Star Sports 2 |
| `star3in` | Star Sports 3 |

### Sony Sports
| ID | Channel |
|----|---------|
| `ten1endia` | Sony Sports Ten 1 |
| `ten2endia` | Sony Sports Ten 2 |
| `ten3endia` | Sony Sports Ten 3 |
| `sonysixendia` | Sony Sports Ten 5 |

### TNT Sports
| ID | Channel |
|----|---------|
| `bbtsp1` | TNT Sports 1 |
| `bbtsp2` | TNT Sports 2 |
| `bbtsp3` | TNT Sports 3 |
| `bbtsp4` | TNT Sports 4 |

### Super Sport
| ID | Channel |
|----|---------|
| `superspcric` | Super Sport Cricket |
| `superlaliga` | Super Sport LaLiga |
| `superpremierleague` | Super Sport Premier League |
| `superspfb` | Super Sport Football |
| `superspaction` | Super Sport Action |
| `supergs` | Super Sport GrandStand |
| `superspv1` | Super Sport Variety 1 |
| `superspv2` | Super Sport Variety 2 |
| `superspv3` | Super Sport Variety 3 |
| `superspv4` | Super Sport Variety 4 |

### TSN
| ID | Channel |
|----|---------|
| `tsn1ca` | TSN 1 |
| `tsn2ca` | TSN 2 |
| `tsn3ca` | TSN 3 |
| `tsn4ca` | TSN 4 |
| `tsn5ca` | TSN 5 |

### Others
| ID | Channel |
|----|---------|
| `ptvpk` | PTV Sports |
| `asports` | A Sports |
| `astrocric` | Astro Cricket |
| `willowusa` | Willow Sports |
| `geosp` | Geo Super |
| `viaplaysp1` | Viaplay Sports 1 |
| `viaplaysp2` | Viaplay Sports 2 |
| `viaplayextra` | Viaplay Xtra |
| `eurosp1` | EuroSport 1 |
| `eurosp2` | EuroSport 2 |
