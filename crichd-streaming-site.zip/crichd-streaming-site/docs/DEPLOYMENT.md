# Deployment Guide

## Requirements

- PHP 7.4 or higher
- Apache/Nginx web server
- SSL certificate (recommended)
- 100MB disk space minimum

## Apache Configuration

```apache
<VirtualHost *:80>
    ServerName your-domain.com
    DocumentRoot /var/www/crichd

    <Directory /var/www/crichd>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    # Enable gzip compression
    <IfModule mod_deflate.c>
        AddOutputFilterByType DEFLATE text/html text/css text/javascript application/javascript
    </IfModule>

    # Security headers
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-Content-Type-Options "nosniff"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"
</VirtualHost>
```

## Nginx Configuration

```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /var/www/crichd;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php7.4-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Gzip compression
    gzip on;
    gzip_types text/plain text/css application/json application/javascript;
}
```

## Docker Deployment

```dockerfile
FROM php:7.4-apache

# Enable mod_rewrite
RUN a2enmod rewrite headers deflate

# Copy application files
COPY . /var/www/html/

# Set permissions
RUN chown -R www-data:www-data /var/www/html

# Expose port
EXPOSE 80
```

```yaml
# docker-compose.yml
version: '3.8'
services:
  crichd:
    build: .
    ports:
      - "8080:80"
    volumes:
      - ./:/var/www/html
    restart: unless-stopped
```

## Environment Setup

1. Copy config example:
   ```bash
   cp config.example.php config.php
   ```

2. Edit `config.php` with your settings

3. Add channel logos to `logo/` directory

4. Set proper permissions:
   ```bash
   chmod -R 755 .
   chmod -R 777 stream/  # If using local streams
   ```

## SSL Setup (Let's Encrypt)

```bash
sudo apt install certbot python3-certbot-apache
sudo certbot --apache -d your-domain.com
```

## Troubleshooting

### Player not loading
- Check browser console for JS errors
- Verify stream URLs are accessible
- Check CORS headers on stream sources

### PHP errors
- Enable debug mode in config.php
- Check PHP error logs
- Verify PHP version compatibility

### Styling issues
- Clear browser cache
- Check CSS file paths
- Verify Bootstrap CDN is accessible
