# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |

## Reporting a Vulnerability

If you discover a security vulnerability, please follow these steps:

1. **Do not** open a public issue
2. Email security concerns to: [your-email@example.com]
3. Include detailed reproduction steps
4. Allow reasonable time for response before public disclosure

## Security Measures

Current security implementations:
- Input validation on all query parameters
- Output encoding with `htmlspecialchars()`
- Alphanumeric filtering for channel IDs
- No direct SQL queries (no database used)

## Recommended Hardening

For production deployment:
- Enable HTTPS
- Set `X-Frame-Options: SAMEORIGIN`
- Implement Content Security Policy (CSP)
- Add rate limiting
- Validate stream URLs server-side
- Use environment variables for sensitive config
