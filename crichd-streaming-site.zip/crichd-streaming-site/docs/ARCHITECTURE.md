# Architecture Overview

## System Design

```
┌─────────────────────────────────────────────────────────────┐
│                        Client Browser                        │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐   │
│  │  index.php   │  │  play.php    │  │  Player Pages    │   │
│  │  (Channel    │  │  (Wrapper    │  │  (embed.php,    │   │
│  │   Grid)      │  │   + FS)      │  │   plays.php)     │   │
│  └──────┬───────┘  └──────┬───────┘  └────────┬─────────┘   │
│         │                  │                    │             │
│         └──────────────────┴────────────────────┘             │
│                            │                                  │
│                    ┌──────────────┐                          │
│                    │  CDN Players │                          │
│                    │  JWPlayer    │                          │
│                    │  Clappr      │                          │
│                    │  Kaltura     │                          │
│                    └──────────────┘                          │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌──────────────────┐
                    │  Stream Sources  │
                    │  .m3u8 (HLS)     │
                    │  External APIs   │
                    └──────────────────┘
```

## File Responsibilities

| File | Purpose | Input | Output |
|------|---------|-------|--------|
| `index.php` | Channel browser | - | HTML grid |
| `play.php` | Player wrapper | `?c=channel_id` | Embedded iframe |
| `embed.php` | Clappr player | `?id=stream_id` | HLS playback |
| `plays.php` | JWPlayer | `?max=stream_url` | Video playback |
| `kplay.php` | Kaltura player | `?max=stream_url` | Video playback |
| `animal_plannet.php` | JWPlayer playlist | `?max=stream_url` | Playlist playback |
| `playshemaroo.php` | Secure JWPlayer | `?max=stream_url` | Token-protected playback |
| `script.js` | Custom player logic | User interaction | Video controls |
| `style.css` | Main styles | - | Rendered UI |

## Data Flow

1. User visits `index.php` → sees channel grid
2. User clicks channel → navigates to `play.php?c=CHANNEL_ID`
3. `play.php` embeds `embed.php?id=CHANNEL_ID` in iframe
4. `embed.php` loads Clappr player with HLS stream
5. User can toggle fullscreen via custom button

## Security Considerations

- Input validation on `$_GET['c']` (alphanumeric only)
- `htmlspecialchars()` for output encoding
- `X-Frame-Options` recommended for production
- CSP headers recommended for production
- Stream URLs should be validated server-side
